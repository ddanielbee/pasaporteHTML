$(document).ready(function(){
	var feed = new Instafeed({
        get: 'tagged',
        target: "instafeed",
        limit: "30",
        resolution: "standard_resolution",
        tagName: 'malecatmodel',
        clientId: 'bc3ebbdf33a541e081c8a6d2d087e718',
        template: '<li><a target="_blank" href="{{link}}"><img src="{{image}}" /></a></li>'
    });
    feed.run();
})