var app = angular
  .module('todo', [    
    'ngRoute',
    'ngAnimate'
  ]) 
  .config(function ($routeProvider) {
    $routeProvider      
      .when('/', {
        templateUrl: 'views/main.html',
        controller: "TodoController"   
      })
      .otherwise({
        redirectTo: '/'
      });
  });