app.controller('TodoController', function($scope) {
	$scope.todos = [
		{
			content:"Terminar el curso de HTML",
			checked: false
		},
		{
			content: "Verme Inside Out",
			checked: true
		}
	];
	$scope.addTodo = function(todo) {
		if(todo != "")
		{
			var temp = {
				content: todo,
				checked: false
			};
			$scope.todos.push(temp);
		}
	}
});